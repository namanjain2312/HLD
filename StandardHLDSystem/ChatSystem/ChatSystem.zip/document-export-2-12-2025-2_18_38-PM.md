# Chat System

Scope 

Question.1 : What kind of chat app we design ? 1 on 1 or group based ?

Answer : Should support both 

Question.2 : Is this a mobile app ? Or a web app ? Or Both ?

Answer : Both 

Question.3 : What is the scale of this app ? A startup app or massive scale?

Answer : It should support 50 million daily active users (DAU)

Question.4 : For a group chat , what is the group member limit ?

Answer : A maximum of 100 people 

Question.5 : What features are important for the chat app ? Can it support attachment ?

Answer : 1 0n 1 chat , group chat , online indicator . The system support text messages only .

Question.6 : Is end to end encryption required ?

Answer : Not required for now , but we will discuss if time allows 

Question.7 : How long shall we store the chat history ?

Answer : Forever



![image.png](https://eraser.imgix.net/workspaces/NwFEUm2eujDdBk7B6Z1X/pqzq4S07fqcma47xGOPbSlv9Jtt1/cEUxJl5BHKLkJUpUVcTkB.png?ixlib=js-3.7.0 "image.png")

Polling

Long polling

WebSocket

![image.png](https://eraser.imgix.net/workspaces/NwFEUm2eujDdBk7B6Z1X/pqzq4S07fqcma47xGOPbSlv9Jtt1/WrMw-3khcOPrsiA8txn7q.png?ixlib=js-3.7.0 "image.png")

![image.png](https://eraser.imgix.net/workspaces/NwFEUm2eujDdBk7B6Z1X/pqzq4S07fqcma47xGOPbSlv9Jtt1/jnyMAgrn6gDf1siMczYn0.png?ixlib=js-3.7.0 "image.png")



![image.png](https://eraser.imgix.net/workspaces/NwFEUm2eujDdBk7B6Z1X/pqzq4S07fqcma47xGOPbSlv9Jtt1/oIZkCdyktnljs1l7wtLWc.png?ixlib=js-3.7.0 "image.png")

![image.png](https://eraser.imgix.net/workspaces/NwFEUm2eujDdBk7B6Z1X/pqzq4S07fqcma47xGOPbSlv9Jtt1/SwGcV2-Muv1Zs89X5t_P8.png?ixlib=js-3.7.0 "image.png")



![image.png](https://eraser.imgix.net/workspaces/NwFEUm2eujDdBk7B6Z1X/pqzq4S07fqcma47xGOPbSlv9Jtt1/i4_bvGEwiQHNliGgZicFb.png?ixlib=js-3.7.0 "image.png")

Group Flow

![image.png](https://eraser.imgix.net/workspaces/NwFEUm2eujDdBk7B6Z1X/pqzq4S07fqcma47xGOPbSlv9Jtt1/u7bc5Fgx0mOkrJ9IbRncm.png?ixlib=js-3.7.0 "image.png")

Online presence 

HeartBeat Mecahnishm 

Online status fanout 

![image.png](https://eraser.imgix.net/workspaces/NwFEUm2eujDdBk7B6Z1X/pqzq4S07fqcma47xGOPbSlv9Jtt1/v2-ZdR2r-bV_1sXHw35F5.png?ixlib=js-3.7.0 "image.png")

![image.png](https://eraser.imgix.net/workspaces/NwFEUm2eujDdBk7B6Z1X/pqzq4S07fqcma47xGOPbSlv9Jtt1/cKWBPEvd2ZKBRwjWlWNtn.png?ixlib=js-3.7.0 "image.png")





